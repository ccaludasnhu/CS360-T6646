package com.example.cs360projecttwomain;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class weightDB extends SQLiteOpenHelper {

    public weightDB(Context context) {
        super(context, "WeightData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Weightdetails(date TEXT primary key, weight TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists Weightdetails");
    }

    public Boolean insertUserData(String date, String weight){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("weight", weight);
        long result = DB.insert("Weightdetails", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


    public Boolean checkDate(String date){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Weightdetails where date = ?", new String[] {date});

        if(cursor.getCount()>0){
            return true;
        } else {
            return false;
        }
    }

    public Cursor getData() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Weightdetails", null);

        return cursor;
    }

    public Boolean deleteData(String date) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Weightdetails where date = ?", new String[]{date});

        if (cursor.getCount() > 0) {
            long result = DB.delete("Weightdetails", "date=?", new String[]{date});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }









}
