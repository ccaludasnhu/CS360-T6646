package com.example.cs360projecttwomain;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import java.util.Calendar;

public class entryActivity extends AppCompatActivity {
    EditText Weight;
    Button AddButton;
    weightDB DB;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);

        AddButton = findViewById(R.id.addButton);
        Weight = findViewById(R.id.weight);
        DB = new weightDB(this);

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = Weight.getText().toString();
                String date = Calendar.getInstance().MONTH + "/" + Calendar.getInstance().DAY_OF_MONTH;
                //String weight = "150";
                //String date = "10/21";

                if (weight.equals("")){
                    Toast.makeText(entryActivity.this, "Please fill out every field!", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkDate = DB.checkDate(date);

                    if (checkDate == false){
                        Boolean insert = DB.insertUserData(date, weight);

                        if (insert == true) {
                            Toast.makeText(entryActivity.this, "Entry entered!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), gridActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(entryActivity.this, "Adding failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(entryActivity.this,"You have already entered a weight for today!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
