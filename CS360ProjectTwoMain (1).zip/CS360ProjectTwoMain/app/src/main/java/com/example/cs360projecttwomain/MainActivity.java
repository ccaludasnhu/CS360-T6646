package com.example.cs360projecttwomain;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText Username, Password;
    Button LoginButton, RegisterButton;
    UserDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LoginButton = findViewById(R.id.loginButton);
        RegisterButton = findViewById(R.id.registerButton);
        Username = findViewById(R.id.username);
        Password = findViewById(R.id.password);
        DB = new UserDB(this);

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = Username.getText().toString();
                String pass = Password.getText().toString();

                if (user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please fill out every field", Toast.LENGTH_SHORT).show();
                } else{
                    Boolean checkUserPass = DB.checkUsernamePass(user, pass);

                    if(checkUserPass == true) {
                        Toast.makeText(MainActivity.this, "Sign in successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(getApplicationContext(), gridActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = Username.getText().toString();
                String pass = Password.getText().toString();

                if (user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please fill out every field", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUsername = DB.checkUsername(user);

                    if (checkUsername == false) {
                        Boolean insert = DB.insertData(user, pass);

                        if (insert == true) {
                            Toast.makeText(MainActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), gridActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "User already exists!", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

    }




}
