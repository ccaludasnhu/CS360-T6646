package com.example.cs360projecttwomain;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class permissions extends AppCompatActivity {

    Button acceptButton;
    ImageButton cancelButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permissions);

        acceptButton = findViewById(R.id.acceptButton);
        cancelButton = findViewById(R.id.cancelButton);

        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            // enable
                Toast.makeText(permissions.this, "Accepted!", Toast.LENGTH_SHORT).show();
                gridActivity.AllowSendSMS();
                Intent intent = new Intent(getApplicationContext(), gridActivity.class);
                startActivity(intent);

            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gridActivity.DenySendSMS();
                Intent intent = new Intent(getApplicationContext(), gridActivity.class);
                startActivity(intent);
            }
        });
    }
}
