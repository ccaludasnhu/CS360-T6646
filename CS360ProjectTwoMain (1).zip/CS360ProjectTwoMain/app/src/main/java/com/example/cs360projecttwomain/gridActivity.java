package com.example.cs360projecttwomain;

import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.telephony.SmsManager;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import android.widget.ImageButton;
import android.widget.Toast;
import java.util.ArrayList;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class gridActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> date, weight;
    weightDB DB;
    MyAdapter adapter;
    FloatingActionButton fab;
    ImageButton smsNotifications;
    private static boolean smsAuthorized = false;
    private static String PhoneNum = "5042581712";
    private static int goalWeight = 120;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        fab = findViewById(R.id.floatingActionButton);
        smsNotifications = findViewById(R.id.imageButton);
        DB = new weightDB(this);
        date = new ArrayList<>();
        weight = new ArrayList<>();
        recyclerView = findViewById(R.id.rvItems);
        adapter = new MyAdapter(this, date, weight);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displayData();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), entryActivity.class);
                startActivity(intent);
            }
        });

        smsNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), permissions.class);
                startActivity(intent);
            }
        });

    }

    private void displayData(){
        Cursor cursor = DB.getData();
        if(cursor.getCount()==0){
            Toast.makeText(gridActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                date.add(cursor.getString(0));
                weight.add(cursor.getString(1));
            }
        }
    }

    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public static void SendSMSMessage (Context context) {
        String phoneNo = PhoneNum;
        String smsMessage = "Congratulations on hitting your goal weight!";

        if (smsAuthorized){
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMessage, null, null);
            } catch (Exception ex) {
                Toast.makeText(context, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(context, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}
